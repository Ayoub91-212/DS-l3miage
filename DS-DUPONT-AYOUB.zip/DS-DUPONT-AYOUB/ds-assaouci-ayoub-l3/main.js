import { showContent } from "./src/content.mjs";
showContent();
