/**
 * @param {Array<Object>} data - 
 */
export function updateContent(data) {
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const tbody = document.createElement("tbody");

    const headers = ["Name", "Price"];
    const tr = document.createElement("tr");
    for (let i = 0; i < headers.length; i++) {
        const th = document.createElement("th");
        th.textContent = headers[i];
        tr.appendChild(th);
    }
    thead.appendChild(tr);

    // Remplir les lignes de la table
    for (let i = 0; i < data.length; i++) {
        const row = document.createElement("tr");

        const nameCell = document.createElement("td");
        nameCell.textContent = data[i].name;
        if (!data[i].stocked) {
            nameCell.classList.add('not-stocked');
        }
        row.appendChild(nameCell);

        const priceCell = document.createElement("td");
        priceCell.textContent = data[i].price;
        row.appendChild(priceCell);

        tbody.appendChild(row);
    }

    // Ajouter thead et tbody à la table
    table.appendChild(thead);
    table.appendChild(tbody);

    // Ajouter la table au DOMcherche et à la case à cocher
    const appDiv = document.getElementById("app");
    appDiv.innerHTML = ''; // Clear previous content
    appDiv.appendChild(table);
}

// Fonction pour filtrer les données
function filterData(data, query, showStocked) {
    return data.filter(item => {
        const matchesQuery = item.name.toLowerCase().includes(query.toLowerCase());
        const matchesStock = showStocked ? item.stocked : true;
        return matchesQuery && matchesStock;
    });
}

// Fetch et initialisation
async function init() {
    const response = await fetch('/data.json');
    const data = await response.json();
    updateContent(data);

    // barre de recherche & la chechbox
    const searchBar = document.getElementById('search-bar');
    const stockCheck = document.getElementById('stock-check');

    const updateFilteredContent = () => {
        const query = searchBar.value;
        const showStocked = stockCheck.checked;
        const filteredData = filterData(data, query, showStocked);
        updateContent(filteredData);
    };

    searchBar.addEventListener('input', updateFilteredContent);
    stockCheck.addEventListener('change', updateFilteredContent);
}

init();