import { fetchC } from "./dataFetcher.mjs";
import { updateContent } from "./domManipulator.mjs";
export async function showContent() {
  try {
    const content = await fetchC();
    updateContent(content);
    console.log("Content:", content);
  } catch (e) {
    console.log("Erreur", e);
  }
}
