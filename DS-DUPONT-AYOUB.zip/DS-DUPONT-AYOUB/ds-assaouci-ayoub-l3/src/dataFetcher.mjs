export async function fetchC(url = '/data.json') {
    console.log('Récupération des données depuis :', url);
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`La réponse du réseau n'était pas correcte : ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Données récupérées avec succès :', data);
        return data;
    } catch (error) {
        console.error('Erreur lors de la récupération des données :', error);
        throw error;
    }
}